import UIKit

class StatesTableViewController: UITableViewController {

    var states = [State]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        loadStateData()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return states.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StatesCell", for: indexPath) as! StateTableViewCell
        
        //Cell 
        cell.stateNameLabel?.text = "\(states[indexPath.row].name)"
        cell.stateFlagImage?.image = states[indexPath.row].flag
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let row = tableView.indexPathForSelectedRow?.row
        let stateDetailViewController = segue.destination as! StateDetailViewController
        
        let selectedState = states[row!]
            
        stateDetailViewController.name = selectedState.name
        stateDetailViewController.flag = selectedState.flag
        stateDetailViewController.abbreviation = selectedState.abbreviation
        stateDetailViewController.seal = selectedState.seal
        stateDetailViewController.captial = selectedState.capital
        stateDetailViewController.largestCity = selectedState.largestCity
        stateDetailViewController.population = selectedState.population
        stateDetailViewController.area = selectedState.area
        
    }
    
    func loadStateData() {
        
        let state1 = State(name: "California", flag: UIImage(named: "California"), abbreviation: "CA", seal: UIImage(named: "CaliforniaSeal"), capital: "Sacramento", largestCity: "Los Angeles", population: 39.41, area: 163696)
        
        let state2 = State(name: "Nevada", flag: UIImage(named: "Nevada"), abbreviation: "NV", seal: UIImage(named: "NevadaSeal"), capital: "Carson City", largestCity: "Las Vegas", population: 3.08, area: 110567)
        
        let state3 = State(name: "Texas", flag: UIImage(named: "Texas"), abbreviation: "TX", seal: UIImage(named: "TexasSeal"), capital: "Austin", largestCity: "Houston", population: 29, area: 110567)
        
        let state4 = State(name: "Montana", flag: UIImage(named: "Montana"), abbreviation: "MT", seal: UIImage(named: "MontanaSeal"), capital: "Helena", largestCity: "Billings", population: 1.07, area: 147040)
        
        let state5 = State(name: "Florida", flag: UIImage(named: "Florida"), abbreviation: "FL", seal: UIImage(named: "FloridaSeal"), capital: "Tallahassee", largestCity: "Jacksonville", population: 21.5, area: 65755)
        
        let state6 = State(name: "Idaho", flag: UIImage(named: "Idaho"), abbreviation: "ID", seal: UIImage(named: "IdahoSeal"), capital: "Boise", largestCity: "Boise", population: 1.87, area: 8642)
        
        let state7 = State(name: "Orgen", flag: UIImage(named: "Orgen"), abbreviation: "OR", seal: UIImage(named: "OrgenSeal"), capital: "Salem", largestCity: "Portland", population: 3.22, area: 98466)
        
        let state8 = State(name: "Michigan", flag: UIImage(named: "Michigan"), abbreviation: "MI", seal: UIImage(named: "MichiganSeal"), capital: "Lansing", largestCity: "Detroit", population: 9.98, area: 96716)
        
        let state9 = State(name: "Pennsylvania", flag: UIImage(named: "Pennsylvania"), abbreviation: "PA", seal: UIImage(named: "PennsylvaniaSeal"), capital: "Harrisburg", largestCity: "Philadelphia", population: 12.8, area: 46055)
        
        let state10 = State(name: "Utah", flag: UIImage(named: "Utah"), abbreviation: "UT", seal: UIImage(named: "UtahSeal"), capital: "Salt Lake City", largestCity: "Salt Lake City", population: 3.2, area: 84899)
        
        let state11 = State(name: "Arizona", flag: UIImage(named: "Arizona"), abbreviation: "AZ", seal: UIImage(named: "ArizonaSeal"), capital: "Phoenix", largestCity: "Phoenix", population: 7.27, area: 113998)
        
        let state12 = State(name: "Iowa", flag: UIImage(named: "Iowa"), abbreviation: "IA", seal: UIImage(named: "IowaSeal"), capital: "Des Moines", largestCity: "Des Moines", population: 3.16, area: 56272)
        
        let state13 = State(name: "Ohio", flag: UIImage(named: "Ohio"), abbreviation: "OH", seal: UIImage(named: "OhioSeal"), capital: "Columbus", largestCity: "Columbus", population: 11.69, area: 44825)
        
        let state14 = State(name: "Arkansas", flag: UIImage(named: "Arkansas"), abbreviation: "AR", seal: UIImage(named: "ArkansasSeal"), capital: "Little Rock", largestCity: "Little Rock", population: 3.02, area: 53179)
        
        let state15 = State(name: "Wyoming", flag: UIImage(named: "Wyoming"), abbreviation: "WY", seal: UIImage(named: "WyomingSeal"), capital: "Cheyenne", largestCity: "Cheyenne", population: 0.57, area: 97818)
        
        let state16 = State(name: "New York", flag: UIImage(named: "NewYork"), abbreviation: "NY", seal: UIImage(named: "NewYorkSeal"), capital: "Albany", largestCity: "New York", population: 8.4, area: 54555)
        
        let state17 = State(name: "Washington", flag: UIImage(named: "Washington"), abbreviation: "WA", seal: UIImage(named: "WashingtonSeal"), capital: "Olympia", largestCity: "Seattle", population: 7.62, area: 71362)
        
        let state18 = State(name: "Tennessee", flag: UIImage(named: "Tennessee"), abbreviation: "TN", seal: UIImage(named: "TennesseeSeal"), capital: "Nashville", largestCity: "Nashville", population: 6.83, area: 42181)
        
        let state19 = State(name: "Alabama", flag: UIImage(named: "Alabama"), abbreviation: "AL", seal: UIImage(named: "AlabamaSeal"), capital: "Montgomery", largestCity: "Birmingham", population: 4.9, area: 52419)
        
        let state20 = State(name: "Kansas", flag: UIImage(named: "Kansas"), abbreviation: "KS", seal: UIImage(named: "KansasSeal"), capital: "Topeka", largestCity: "Wichita", population: 2.91, area: 82277)
        
        let state21 = State(name: "North Carolina", flag: UIImage(named: "NorthCarolina"), abbreviation: "NC", seal: UIImage(named: "NorthCarolinaSeal"), capital: "Raleigh", largestCity: "Charlotte", population: 10.5, area: 53819)
        
        let state22 = State(name: "Minnesota", flag: UIImage(named: "Minnesota"), abbreviation: "MI", seal: UIImage(named: "MinnesotaSeal"), capital: "Saint Paul", largestCity: "Minneapolis", population: 5.64, area: 86943)
        
        let state23 = State(name: "South Dakota", flag: UIImage(named: "SouthDakota"), abbreviation: "SD", seal: UIImage(named: "SouthDakotaSeal"), capital: "Pierre", largestCity: "Sioux Falls", population: 0.88, area: 77184)
        
        let state24 = State(name: "New Mexico", flag: UIImage(named: "NewMexico"), abbreviation: "NM", seal: UIImage(named: "NewMexicoSeal"), capital: "Santa Fe", largestCity: "Albuquerque", population: 2.01, area: 121697)
        
        let state25 = State(name: "Georgia", flag: UIImage(named: "Georgia"), abbreviation: "GA", seal: UIImage(named: "GeorgiaSeal"), capital: "Atlanta", largestCity: "Atlanta", population: 10.62, area: 59425)

        states += [state1, state2, state3, state4, state5, state6, state7, state8, state9, state10, state11, state12, state13, state14, state15, state16, state17, state18, state19, state20, state21, state22, state23, state24, state25]
    }
    
}



